package mg.studio.weatherappdesign;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;


public class MainActivity extends AppCompatActivity {
    TextView tempTV;
    TextView date;
    TextView city;
    TextView dayt1;
    TextView dayt2;
    TextView dayt3;
    TextView dayt4;
    TextView day1;
    TextView day2;
    TextView day3;
    TextView day4;

    Button btn;
    ImageView weatherimage;
    //String weatherAPI = "https://free-api.heweather.com/s6/weather/now?key=86a3c4999f6346248511a308d60856cd&location=";
    String weatherAPI = "http://wthrcdn.etouch.cn/weather_mini?citykey=101200101";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindID();
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //String cityname = weatherAPI + city.getText().toString();
                String cityname = weatherAPI;
                new MyTask().execute(cityname);
                Toast.makeText(MainActivity.this, "Weather Updated", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void bindID() {
        city = findViewById(R.id.tv_location);
        btn = findViewById(R.id.button);
        tempTV = findViewById(R.id.temperature_of_the_day);
        weatherimage = findViewById(R.id.img_weather_condition);
        date = findViewById(R.id.tv_date);
        dayt1 = findViewById(R.id.one);
        dayt2 = findViewById(R.id.two);
        dayt3 = findViewById(R.id.three);
        dayt4 = findViewById(R.id.four);
        day1 = findViewById(R.id.oneday);
        day2 = findViewById(R.id.twoday);
        day3 = findViewById(R.id.threeday);
        day4 = findViewById(R.id.fourday);
    }
    class MyTask extends AsyncTask<String, String, String> {
        StringBuffer stringBuffer = new StringBuffer();

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = null;
                if (connection.getResponseCode() == 200) {
                    inputStream = connection.getInputStream();
                } else {
                    return "network_failed";
                }
                InputStreamReader reader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(reader);//缓存器
                String temp = "";
                while ((temp = bufferedReader.readLine()) != null) {
                    stringBuffer.append(temp);
                }
                bufferedReader.close();
                reader.close();
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return stringBuffer.toString();
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals("network_failed")) {
                Toast.makeText(MainActivity.this, "网络失败", Toast.LENGTH_SHORT).show();
            }
            else {
                try {
                    JSONObject object = new JSONObject(s);
                    //JSONArray array = object.getJSONArray("");
                    JSONObject object1 = object.getJSONObject("data");
                    JSONArray array = object1.getJSONArray("forecast");
                    String time0 = array.getJSONObject(0).getString("date");
                    time0 = time0.substring(2);

                    if(time0.equals("星期一"))
                    { time0 = "Monday"; }
                    if(time0.equals("星期二"))
                    { time0 = "Tuesday"; }
                    if(time0.equals("星期三"))
                    { time0 = "Wednesday"; }
                    if(time0.equals("星期四"))
                    { time0 = "Thursday"; }
                    if(time0.equals("星期五"))
                    { time0 = "Friday"; }
                    if(time0.equals("星期六"))
                    { time0 = "Saturday"; }
                    if(time0.equals("星期天"))
                    { time0 = "Sunday"; }

                    String time1 = array.getJSONObject(1).getString("date");
                    time1 = time1.substring(2);
                    if(time1.equals("星期一"))
                    { time1 = "Monday"; }
                    if(time1.equals("星期二"))
                    { time1 = "Tuesday"; }
                    if(time1.equals("星期三"))
                    { time1 = "Wednesday"; }
                    if(time1.equals("星期四"))
                    { time1 = "Thursday"; }
                    if(time1.equals("星期五"))
                    { time1 = "Friday"; }
                    if(time1.equals("星期六"))
                    { time1 = "Saturday"; }
                    if(time1.equals("星期天"))
                    { time1 = "Sunday"; }

                    String time2 = array.getJSONObject(2).getString("date");
                    time2 = time2.substring(2);
                    if(time2.equals("星期一"))
                    { time2 = "Monday"; }
                    if(time2.equals("星期二"))
                    { time2 = "Tuesday"; }
                    if(time2.equals("星期三"))
                    { time2 = "Wednesday"; }
                    if(time2.equals("星期四"))
                    { time2 = "Thursday"; }
                    if(time2.equals("星期五"))
                    { time2 = "Friday"; }
                    if(time2.equals("星期六"))
                    { time2 = "Saturday"; }
                    if(time2.equals("星期天"))
                    { time2 = "Sunday"; }

                    String time3 = array.getJSONObject(3).getString("date");
                    time3 = time3.substring(2);
                    if(time3.equals("星期一"))
                    { time3 = "Monday"; }
                    if(time3.equals("星期二"))
                    { time3 = "Tuesday"; }
                    if(time3.equals("星期三"))
                    { time3 = "Wednesday"; }
                    if(time3.equals("星期四"))
                    { time3 = "Thursday"; }
                    if(time3.equals("星期五"))
                    { time3 = "Friday"; }
                    if(time3.equals("星期六"))
                    { time3 = "Saturday"; }
                    if(time3.equals("星期天"))
                    { time3 = "Sunday"; }

                    String time4 = array.getJSONObject(4).getString("date");
                    time4 = time4.substring(2);
                    if(time4.equals("星期一"))
                    { time4 = "Monday"; }
                    if(time4.equals("星期二"))
                    { time4 = "Tuesday"; }
                    if(time4.equals("星期三"))
                    { time4 = "Wednesday"; }
                    if(time4.equals("星期四"))
                    { time4 = "Thursday"; }
                    if(time4.equals("星期五"))
                    { time4 = "Friday"; }
                    if(time4.equals("星期六"))
                    { time4 = "Saturday"; }
                    if(time4.equals("星期天"))
                    { time4 = "Sunday"; }

                    String temp0 = array.getJSONObject(0).getString("high");
                    temp0 = temp0.substring(2,temp0.indexOf("℃"));

                    String temp1 = array.getJSONObject(1).getString("high");
                    temp1 = temp1.substring(2);
                    String temp2 = array.getJSONObject(2).getString("high");
                    temp2 = temp2.substring(2);
                    String temp3 = array.getJSONObject(3).getString("high");
                    temp3 = temp3.substring(2);
                    String temp4 = array.getJSONObject(4).getString("high");
                    temp4 = temp4.substring(2);

                    String weather = array.getJSONObject(0).getString("type");
                    //Log.d("json数据", time);
                    //Log.d("json数据", String.valueOf(array));
                    //JSONObject object1 = array.getJSONObject(0);
                    //JSONObject object3 = object1.getJSONObject("update");
                    //String time = object3.getString("utc");
                    date.setText(time0);
                    tempTV.setText(temp0);

                    day1.setText(temp1);
                    dayt1.setText(time1);
                    day2.setText(temp2);
                    dayt2.setText(time2);
                    day3.setText(temp3);
                    dayt3.setText(time3);
                    day4.setText(temp4);
                    dayt4.setText(time4);

                    //JSONObject object2 = object1.getJSONObject("now");
                    //String weather = object2.getString("cond_txt");
                    if (weather.equals("阴")) {
                        weatherimage.setImageResource(R.drawable.windy_small);
                    }
                    if (weather.equals("多云")) {
                        weatherimage.setImageResource(R.drawable.partly_sunny_small);
                    }
                    if (weather.equals("小雨")) {
                        weatherimage.setImageResource(R.drawable.rainy_small);
                    }
                    if (weather.equals("雨")) {
                        weatherimage.setImageResource(R.drawable.rainy_up);
                    }
                    if (weather.equals("晴")) {
                        weatherimage.setImageResource(R.drawable.sunny_small);
                    }
                    //String wind = object2.getString("wind_dir") + object2.getString("wind_sc") + "级";
                    //String temp = object2.getString("tmp");
                    //weatherTV.setText(weather);
                    //wingTV.setText(wind);
                    //tempTV.setText(temp);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    }

    /*public void btnClick(View view) {
        new DownloadUpdate().execute();
    }


    private class DownloadUpdate extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... strings) {
            String stringUrl = "https://mpianatra.com/Courses/info.txt";
            HttpURLConnection urlConnection = null;
            BufferedReader reader;

            try {
                URL url = new URL(stringUrl);

                // Create the request to get the information from the server, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Mainly needed for debugging
                    Log.d("TAG", line);
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.
                    return null;
                }
                //The temperature
                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String temperature) {
            //Update the temperature displayed
            ((TextView) findViewById(R.id.temperature_of_the_day)).setText(temperature);
        }
    }
}*/
